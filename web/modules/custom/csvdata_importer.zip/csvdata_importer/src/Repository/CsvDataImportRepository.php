<?php

namespace Drupal\Csvdata_importer\Repository;

use Drupal\node\Entity\Node;
use Drupal\Component\Utility\Html;
use Drupal\Core\Entity\EntityTypeManager;
use Drupal\user\Entity\User;
use Drupal\paragraphs\Entity\Paragraph;

class CsvDataImportRepository{

    /**
     * Perform tasks when a batch is complete.
     *
     *   Return message of success or error.
     *
     * @param bool $success
     *   A boolean indicating whether the batch operation successfully concluded.
     * @param int $results
     *   The results from the batch process.
   */
    public static function csvImportFinished($success, $results) {

        if ($success) {
          $message = \Drupal::translation()->formatPlural(
            count($results),
            'One Account content imported.', '@count contents imported.'
          );
        }
        else {
          $message = t('Finished with error.');
        }
        // Issue related to by-passing the class instantiation.
        // So using static function call and not via dependency.
        \Drupal::messenger()->addMessage($message);
      }

    /**
     * Batch callback for Import content from csv file.
     *
     * @param array $output_data
     *   Data which is present in the Csv file.
     * @param string $type
     *   That will contain type of Account 
     * @param array $context
     *   That will contain information about the
     *   status of the batch. The values in $context will retain their
     *   values as the batch progresses.
    */
      public static function csvImportAccount(array $output_data, array &$context) {
        \Drupal::logger('csvdata_importer')->notice('<pre><code>' . print_r($output_data, TRUE) . '</code></pre>' );
        $userId = \Drupal::currentUser()->id();
          $node = Node::create([
            'type' => 'aielead',
            'langcode' => 'en',
            'title' => $output_data['title'],
            'uid' => $userId
          ]);
          $node->save();
        // $node = Node::create([
        //   'type' => 'aielead',
        //   'langcode' => 'en',
        //   'title' => $output_data['title'],
        //   'uid' => $userId
        // ]
      
      
      $context['results'][] = $output_data['title'];
      $context['message'] = t('Created @title', array('@title' => $output_data['title']));
    
        
        // switch($type){
        //     case 'aielead':
        //         return self::importleadCsv($output_data, $context);
        //         break;

        //     case 'aieexpert':
        //         return self::importexpertCsv($output_data, $context);
        //         break;
            
        //     case 'a':
        //         return self::importMunicipalityCsv($output_data, $context);
        //         break;
        // }
      }

   /**
     * Get all nodes of a certain type
     * @param $type
     * @return array
     * 'a' is Account machine name
   */ 
  public static function getAccountAllNodes($type) {

    $nids = \Drupal::entityQuery('node')->condition('type','a')->execute();

    if (is_array($nids) && count($nids) > 0) {
      $nodes = \Drupal\node\Entity\Node::loadMultiple($nids);
      return $nodes;
    }    
    return array();
  }

  /**
   * Get a Account by its name and if applicable its parents name
   * @param $municipalityName // lead1, expert1,
   * @param null $parentName // Account  is parent like Account1, Account2
   * @return mixed|null
   * 'a' is Account machine name
   */

  // public static function getAccountByName($AccounttypeName, $AccountName = NULL) {
  //   if ($AccounttypeName == '') {
  //     return NULL;
  //   }
  //   $propertyCondition = ['type' => 'a', 'title' => $AccounttypeName];

  //   if (isset($AccountName)) {
  //     $parent =  \Drupal::entityTypeManager()->getStorage('node')->loadByProperties(['type' => 'a', 'title' => $AccountName]);
  //     $parent = array_shift($parent);
      
  //     if (isset($parent) && $AccountName != $AccounttypeName) {
  //       $propertyCondition += ['field_accountid' => $parent->id()];       
  //     }
  //   }
  //   $accountNode =  \Drupal::entityTypeManager()->getStorage('node')->loadByProperties($propertyCondition);
  //   if (isset($$accountNode) && count($$accountNode) > 0) {
  //     $accountNode = reset($accountNode);
  //     return $accountNode;
  //   }

  //    // Create a new node.
  //    $userId = \Drupal::currentUser()->id();
  //    $values = array(
  //      'type' => 'a',
  //      'title' => $AccounttypeName,
  //      'uid' => $userId,
  //      'status' => 0,
  //      'comment' => 0,
  //      'promote' => 0,
  //    );
  //    $newAccount = \Drupal::entityTypeManager()->getStorage('node')->create($values);

  //    if (isset($parent)) {
  //     $newAccount->set('field_accountid', [$parent->id()]);
  //     $newAccount->save();
  //   }

  //   return $newAccount;
  // }
  
/**
   * Process aielead information
   * @param $row
   * @param null $row
   */
  // public static function importleadCsv($row, array &$context) {
  //    // First row column's should avoid which contains field labels.
  //    $AccounttypeName = $row[0];
  //    $AccountName = $row[1];
  //    $leadname = $row[2];
  //    $leadmail= $row[3];
  //    try {
  //     $account= self::getAccountByName($AccounttypeName, $AccountName);
  //     if (isset($account)) {
  //       $parent = self::getAccountByName($AccountName);

  //       if (isset($parent)) {
  //         $account->set('field_accountid', [$parent->id()]);
  //       }
  //       $account->set('field_aielead_email', $leadmail);
  //       $account->set('field_aielead_name', $leadname);
  //       // Save changes.
  //       $account->save(); 

  //       $context['results'][] = $account->id();
  //     }
  //    }
  //    catch(Exception $exception){
  //     \Drupal::logger('Account- Aielead')->error('@name - @error', ['@name' => $AccounttypeName, '@error' => $exception->getMessage()]);
  //     $context['results']['errors'][] = self::t('[Account IMPORT ERROR MESSAGE @error', array('@error' => $exception->getMessage()));
  //    }
  
  // }

/**
   * Process aieexpert information
   * @param $row
   * @param null $row
   */
  // public static function importexpertCsv($row, array &$context) {
  //    // First row column's should avoid which contains field labels.
  //    $AccounttypeName = $row[0];
  //    $AccountName = $row[1];
  //    $expertname = $row[2];
  //    $expertmail= $row[3];
  //    try {
  //     $account= self::getAccountByName($AccounttypeName, $AccountName);
  //     if (isset($account)) {
  //       $parent = self::getAccountByName($AccountName);

  //       if (isset($parent)) {
  //         $account->set('field_accountid', [$parent->id()]);
  //       }
  //       $account->set('field_aieexpert_email', $leadmail);
  //       $account->set('field_aieexpert_name', $leadname);
  //       // Save changes.
  //       $account->save(); 

  //       $context['results'][] = $account->id();
  //     }
  //    }
  //    catch(Exception $exception){
  //     \Drupal::logger('Account- Aieexpert')->error('@name - @error', ['@name' => $AccounttypeName, '@error' => $exception->getMessage()]);
  //     $context['results']['errors'][] = self::t('[Account IMPORT ERROR MESSAGE @error', array('@error' => $exception->getMessage()));
  //    }
  
  // }

  /**
   * Process aielead information
   * @param $row
   * @param null $row
   */
//   public static function importAccountCsv($row, array &$context) {
//     // First row column's should avoid which contains field labels.
//     $AccounttypeName = $row[0];
//     $AccountName = $row[1];
//     $visibility = $row[2];
//     $company = $row[3];
//     $sector = $row[4];
//     $topachivements = $row[5];
//     $toppriority = $row[6];
//     $pipeline = $row[7];
//     $keyengagements = $row[8];
//     $accountNameEn = $row[8];
//     try {
//      $account= self::getAccountByName($AccounttypeName, $AccountName);
//      if (isset($account)) {
//        $parent = self::getAccountByName($AccountName);

//        if (isset($parent)) {
//          $account->set('field_accountid', [$parent->id()]);
//        }
//        $account->set('field_visibility', $visibility);
//        $account->set('field_companyname', $company);
//        $account->set('field_sector', $sector);
//        $account->set('field_topachievements', $topachivements);
//        $account->set('field_toppriority', $toppriority);
//        $account->set('field_pipeline', $pipeline);
//        $account->set('field_keyengagements', $keyengagements);
//        $account->set('status', 1);
//        \Drupal::logger('Account')->notice('<pre><code>' . print_r($row, TRUE) . '</code></pre>' );
//        // Save changes.
//        $account->save(); 
       
//        $accountFR = $account->addTranslation('en');    
//           $accountFR->set('title', $accountNameEn);
//           $accountFR->save();
       

//        $context['results'][] = $account->id();
//      }
//     }
//     catch(Exception $exception){
//      \Drupal::logger('Account')->error('@name - @error', ['@name' => $AccounttypeName, '@error' => $exception->getMessage()]);
//      $context['results']['errors'][] = self::t('[Account IMPORT ERROR MESSAGE @error', array('@error' => $exception->getMessage()));
//     }
 
//  }


}